﻿# software-renderer
Gráficas por Computadora 

- Python 3.7 

- Programa principal -- > python project.py 

-- Librerías que consume dicho programa principal -- libs.py 
